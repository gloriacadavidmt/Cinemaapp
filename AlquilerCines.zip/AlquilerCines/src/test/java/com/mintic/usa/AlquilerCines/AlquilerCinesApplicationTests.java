package com.mintic.usa.AlquilerCines;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlquilerCinesApplicationTests {

	@Test
	void contextLoads() {
	}

}
