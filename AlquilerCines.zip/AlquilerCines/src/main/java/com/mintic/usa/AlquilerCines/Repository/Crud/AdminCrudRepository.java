package com.mintic.usa.AlquilerCines.Repository.Crud;

import com.mintic.usa.AlquilerCines.modelo.admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminCrudRepository extends CrudRepository<admin, Integer> {
}
