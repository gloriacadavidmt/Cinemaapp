package com.mintic.usa.AlquilerCines.Repository.Crud;

import com.mintic.usa.AlquilerCines.modelo.message;
import org.springframework.data.repository.CrudRepository;

public interface MessageCrudRepository extends CrudRepository<message, Integer> {
}
