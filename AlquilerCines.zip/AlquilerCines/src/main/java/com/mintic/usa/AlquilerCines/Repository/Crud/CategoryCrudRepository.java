package com.mintic.usa.AlquilerCines.Repository.Crud;

import com.mintic.usa.AlquilerCines.modelo.category;
import org.springframework.data.repository.CrudRepository;


public interface CategoryCrudRepository extends CrudRepository<category, Integer> {
}
