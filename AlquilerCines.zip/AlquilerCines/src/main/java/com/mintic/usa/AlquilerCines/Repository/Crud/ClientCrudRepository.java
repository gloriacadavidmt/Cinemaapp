package com.mintic.usa.AlquilerCines.Repository.Crud;

import com.mintic.usa.AlquilerCines.modelo.client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<client, Integer> {
}
