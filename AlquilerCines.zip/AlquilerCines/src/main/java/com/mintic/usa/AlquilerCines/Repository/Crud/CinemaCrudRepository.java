package com.mintic.usa.AlquilerCines.Repository.Crud;

import com.mintic.usa.AlquilerCines.modelo.cinema;
import org.springframework.data.repository.CrudRepository;

public interface CinemaCrudRepository extends CrudRepository<cinema, Integer> {
}
