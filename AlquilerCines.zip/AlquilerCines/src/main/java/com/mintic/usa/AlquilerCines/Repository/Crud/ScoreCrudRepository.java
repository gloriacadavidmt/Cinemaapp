package com.mintic.usa.AlquilerCines.Repository.Crud;

import com.mintic.usa.AlquilerCines.modelo.score;
import org.springframework.data.repository.CrudRepository;

public interface ScoreCrudRepository extends CrudRepository<score, Integer> {
}
