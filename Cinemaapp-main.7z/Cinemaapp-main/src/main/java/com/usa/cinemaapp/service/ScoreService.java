/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.usa.cinemaapp.service;

import com.usa.cinemaapp.model.Score;
import com.usa.cinemaapp.model.Repository.ScoreRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author luis_
 */
@Service
public class ScoreService {
    @Autowired
    private ScoreRepository scoreRepository;
    
    public Score setInsert(Score score){
        return scoreRepository.setInsert(score);
    }

    public Score setUpdate(Score score){
        return scoreRepository.setUpdate(score);
    }

    public void setDelete(Integer id){
        scoreRepository.setDelete(id);
    }

    public Score getOne(Integer id){
        return scoreRepository.getOne(id);
    }
    
    public List<Score> getAll(){
        return scoreRepository.getall();
    }
    
}