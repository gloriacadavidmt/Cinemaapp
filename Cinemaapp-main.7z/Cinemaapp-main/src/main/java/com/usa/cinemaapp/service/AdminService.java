/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.usa.cinemaapp.service;

import com.usa.cinemaapp.model.Admin;
import com.usa.cinemaapp.Repository.AdminRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author luis_
 */
@Service
public class AdminService {
    @Autowired
    private AdminRepository adminRepository;
    
    public Admin setInsert(Admin admin){
        return adminRepository.setInsert(admin);
    }

    public Admin setUpdate(Admin admin){
        return adminRepository.setUpdate(admin);
    }

    public void setDelete(Integer id){
        adminRepository.setDelete(id);
    }

    public Admin getOne(Integer id){
        return adminRepository.getOne(id);
    }
    
    public List<Admin> getAll(){
        return adminRepository.getall();
    }
    
}

