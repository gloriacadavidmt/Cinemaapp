/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.usa.cinemaapp.repository;

import com.usa.cinemaapp.crudrepository.ScoreCRUDRepository;
import com.usa.cinemaapp.model.Score;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author luis_
 */
@Repository
public class ScoreRepository {
    @Autowired
    private ScoreCRUDRepository  scoreCRUDRepository;
    
    public Score setInsert(Score score){
        Optional<Score> obj = scoreCRUDRepository.findById(score.getScoreId());
        if (obj.isEmpty() == true)
            return scoreCRUDRepository.save(score);
        else
            return null;
    }
    
    public Score setUpdate(Score score){
        Optional<Score> obj = scoreCRUDRepository.findById(score.getScoreId());
        if (obj.isEmpty() == false)
            return scoreCRUDRepository.save(score);
        else
            return null;
    }
    
    public void setDelete(Integer id){
        Optional<Score> obj = scoreCRUDRepository.findById(id);
        if (obj.isEmpty() == false)
            scoreCRUDRepository.deleteById(id);
            
    }
    
    public List<Score> getall(){
        return (List<Score>) scoreCRUDRepository.findAll();
    }
    
    public Score getOne(Integer id){
        Optional<Score> obj = scoreCRUDRepository.findById(id);
        Score devolver;
        if (obj.isEmpty() == false)
            devolver = obj.get();
        else
            devolver = null;
        return  devolver;
    }    
    
}
