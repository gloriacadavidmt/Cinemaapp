package com.usa.cinemaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
